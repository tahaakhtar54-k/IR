import json
import math
import re
import os
import tkinter as tk
from tkinter import ttk, messagebox

#Porter Stemmer
def is_vowel(w, i):
    c = w[i]
    if c in 'aeiou': return True
    if c == 'y' and i > 0: return not is_vowel(w, i - 1)
    return False

def measure(s):
    m, in_v = 0, False
    for i in range(len(s)):
        if is_vowel(s, i): in_v = True
        elif in_v: m += 1; in_v = False
    return m

def has_vowel(s):
    return any(is_vowel(s, i) for i in range(len(s)))

def ends_cvc(w):
    n = len(w)
    if n < 3: return False
    return (not is_vowel(w, n-3) and is_vowel(w, n-2) and
            not is_vowel(w, n-1) and w[n-1] not in 'wxy')

def has_suffix(w, sfx):
    return w[:-len(sfx)] if w.endswith(sfx) else None

def stem(word):
    w = word.lower()
    if len(w) <= 2: return w
    s = None
    if   (s := has_suffix(w, 'sses')) is not None: w = s + 'ss'
    elif (s := has_suffix(w, 'ies'))  is not None: w = s + 'i'
    elif not w.endswith('ss') and (s := has_suffix(w, 's')) is not None: w = s
    extra = False
    if   (s := has_suffix(w, 'eed')) is not None:
        if measure(s) > 0: w = s + 'ee'
    elif (s := has_suffix(w, 'ed'))  is not None:
        if has_vowel(s): w = s; extra = True
    elif (s := has_suffix(w, 'ing')) is not None:
        if has_vowel(s): w = s; extra = True
    if extra:
        if   has_suffix(w, 'at') is not None: w += 'e'
        elif has_suffix(w, 'bl') is not None: w += 'e'
        elif has_suffix(w, 'iz') is not None: w += 'e'
        else:
            n = len(w)
            if n > 1 and w[-1] == w[-2] and w[-1] not in 'lsz' and not is_vowel(w, n-1):
                w = w[:-1]
            elif measure(w) == 1 and ends_cvc(w): w += 'e'
    if (s := has_suffix(w, 'y')) is not None and has_vowel(s): w = s + 'i'
    for sfx, rep in [('ational','ate'),('tional','tion'),('enci','ence'),('anci','ance'),
                     ('izer','ize'),('abli','able'),('alli','al'),('entli','ent'),
                     ('eli','e'),('ousli','ous'),('ization','ize'),('ation','ate'),
                     ('ator','ate'),('alism','al'),('iveness','ive'),('fulness','ful'),
                     ('ousness','ous'),('aliti','al'),('iviti','ive'),('biliti','ble')]:
        if (s := has_suffix(w, sfx)) is not None and measure(s) > 0: w = s + rep; break
    for sfx, rep in [('icate','ic'),('ative',''),('alize','al'),('iciti','ic'),
                     ('ical','ic'),('ful',''),('ness','')]:
        if (s := has_suffix(w, sfx)) is not None and measure(s) > 0: w = s + rep; break
    for sfx in ['al','ance','ence','er','ic','able','ible','ant','ement','ment',
                'ent','ion','ou','ism','ate','iti','ous','ive','ize']:
        if (s := has_suffix(w, sfx)) is not None:
            if sfx == 'ion':
                if s and s[-1] in 'st' and measure(s) > 1: w = s; break
            elif measure(s) > 1: w = s; break
    if (s := has_suffix(w, 'e')) is not None:
        m = measure(s)
        if m > 1: w = s
        elif m == 1 and not ends_cvc(s): w = s
    if len(w) > 1 and w[-1] == 'l' and w[-2] == 'l' and measure(w) > 1: w = w[:-1]
    return w

def load_indices():
    base = os.path.dirname(os.path.abspath(__file__))
    def load(name):
        with open(os.path.join(base, name), 'r') as f:
            return json.load(f)
    tfidf     = load('tfidf_index.json')
    df        = load('df_index.json')
    norms     = load('doc_norms.json')
    docmap    = load('doc_map.json')
    stopwords = set()
    with open(os.path.join(base, 'Stopword-List.txt'), 'r') as f:
        for line in f:
            line = line.strip()
            if line: stopwords.add(stem(line))
    return tfidf, df, norms, docmap, stopwords

def vsm_query(raw_query, tfidf, df, norms, docmap, stopwords, alpha=0.005):
    N = len(docmap)

    # Tokenise and stem query
    words = re.findall(r'[a-zA-Z]+', raw_query)
    query_tf = {}
    for w in words:
        s = stem(w.lower())
        if s in stopwords: continue
        query_tf[s] = query_tf.get(s, 0) + 1

    if not query_tf:
        return []

    # Build query tf-idf vector
    query_vec = {}
    for term, qtf in query_tf.items():
        if term not in df: continue
        idf = math.log(N / df[term])
        query_vec[term] = qtf * idf

    query_norm = math.sqrt(sum(v*v for v in query_vec.values()))
    if query_norm == 0:
        return []

    # Accumulate dot products
    dot_products = {}
    for term, q_score in query_vec.items():
        if term not in tfidf: continue
        for doc_id, d_score in tfidf[term].items():
            dot_products[doc_id] = dot_products.get(doc_id, 0.0) + q_score * d_score

    # Compute cosine similarity and filter
    results = []
    for doc_id, dot in dot_products.items():
        d_norm = norms.get(doc_id, 1.0)
        cosine = dot / (query_norm * d_norm)
        if cosine >= alpha:
            results.append({
                'doc_id':   int(doc_id),
                'score':    cosine,
                'filename': docmap.get(doc_id, 'unknown')
            })

    # Rank by cosine similarity descending
    results.sort(key=lambda x: x['score'], reverse=True)
    return results

class VSMApp:
    def __init__(self, root):
        self.root = root
        self.root.title("VSM Information Retrieval System")
        self.root.geometry("1080x700")
        self.root.configure(bg="#080808")
        self.root.resizable(True, True)

        # Base typography
        self.FONT     = ("Segoe UI", 10)
        self.BOLD     = ("Segoe UI Black", 10)
        self.HEADLINE = ("Segoe UI Black", 15)
        self.MONO     = ("Consolas", 11)
        self.root.option_add("*Font", self.FONT)
        self.root.option_add("*HighlightThickness", 0)

        # Colour palette
        self.BG      = "#080808"
        self.SURFACE = "#140808"
        self.BORDER  = "#3c0d0d"
        self.CARD    = "#1c0b0b"
        self.ACCENT  = "#ef4444"
        self.ACCENT2 = "#f87171"
        self.TEXT    = "#f8fafc"
        self.MUTED   = "#a1a1aa"
        self.FAIL    = "#fca5a5"
        self.PASS    = "#fb7185"

        self.style = ttk.Style(self.root)
        self.style.theme_use('clam')
        self.style.configure('Accent.TButton',
                             background=self.ACCENT, foreground='white',
                             font=(self.BOLD[0], 11, 'bold'),
                             borderwidth=0)
        self.style.map('Accent.TButton',
                       background=[('active', '#b91c1c')])
        self.style.configure('Card.TFrame', background=self.CARD)
        self.style.configure('Card.TLabel', background=self.CARD, foreground=self.TEXT)
        self.style.configure('Result.Treeview',
                             background=self.CARD, fieldbackground=self.CARD,
                             foreground=self.TEXT, rowheight=28,
                             bordercolor=self.BORDER, borderwidth=0)
        self.style.configure('Result.Treeview.Heading',
                             background=self.SURFACE, foreground=self.TEXT,
                             font=(self.BOLD[0], 10), relief='flat')
        self.style.map('Result.Treeview',
                       background=[('selected', self.ACCENT)],
                       foreground=[('selected', 'white')])

        # Load data
        try:
            self.tfidf, self.df, self.norms, self.docmap, self.stopwords = load_indices()
            self.N = len(self.docmap)
        except FileNotFoundError as e:
            messagebox.showerror("Error", f"Index file not found:\n{e}\n\nRun vsm_preprocessing.exe first.")
            root.destroy(); return

        self.alpha   = 0.005
        self.history = []
        self._build_ui()

    def _build_ui(self):
        # Header
        hdr = tk.Frame(self.root, bg=self.SURFACE, height=72)
        hdr.pack(fill='x', side='top')
        hdr.pack_propagate(False)

        tk.Label(hdr, text="VSM", bg=self.ACCENT, fg="white",
                 font=(self.BOLD[0], 15, "bold"),
                 width=4, relief='flat').pack(side='left', padx=(20,12), pady=14)

        tk.Frame(hdr, bg=self.SURFACE).pack(side='left', padx=(0,0), pady=12)
        tk.Label(hdr, text="Vector Space Model — IR System",
                 bg=self.SURFACE, fg=self.TEXT,
                 font=(self.BOLD[0], 14)).pack(side='left')
        tk.Label(hdr, text=f"   •   {self.N} documents   •   {len(self.tfidf)} terms",
                 bg=self.SURFACE, fg=self.MUTED,
                 font=(self.FONT[0], 10)).pack(side='left', padx=(10,0), pady=14)

        tk.Label(hdr, text="TF·IDF  •  Cosine",
                 bg=self.SURFACE, fg=self.ACCENT,
                 font=(self.FONT[0], 9), relief='solid', bd=1, padx=10, pady=5
                 ).pack(side='right', padx=20, pady=12)

        # Body
        body = tk.Frame(self.root, bg=self.BG)
        body.pack(fill='both', expand=True, padx=16, pady=(12,16))

        left = tk.Frame(body, bg=self.SURFACE, width=360)
        left.pack(side='left', fill='y', padx=(0,12))
        left.pack_propagate(False)

        right = tk.Frame(body, bg=self.BG)
        right.pack(side='left', fill='both', expand=True)

        self._build_left(left)
        self._build_right(right)

    def _section_label(self, parent, text):
        tk.Label(parent, text=text, bg=parent['bg'], fg=self.MUTED,
                 font=(self.FONT[0], 9, 'bold')).pack(anchor='w', padx=14, pady=(12,4))

    def _build_left(self, parent):
        search_card = tk.Frame(parent, bg=self.CARD, bd=0)
        search_card.pack(fill='x', padx=16, pady=(0,14))
        tk.Label(search_card, text="Search query", bg=self.CARD, fg=self.TEXT,
                 font=(self.BOLD[0], 12)).pack(anchor='w', padx=14, pady=(14,8))

        ta_frame = tk.Frame(search_card, bg=self.BORDER)
        ta_frame.pack(fill='x', padx=14, pady=(0,12))
        self.query_input = tk.Text(
            ta_frame, height=5, bg=self.SURFACE, fg=self.TEXT,
            insertbackground=self.ACCENT,
            font=self.FONT, relief='flat', bd=0,
            wrap='word', selectbackground=self.ACCENT, selectforeground="white"
        )
        self.query_input.pack(fill='both', expand=True, padx=6, pady=6)
        self._set_placeholder()
        self.query_input.bind('<Return>', lambda e: (self._run_query(), 'break'))

        button_frame = tk.Frame(search_card, bg=self.CARD)
        button_frame.pack(fill='x', padx=14, pady=(0,12))
        ttk.Button(button_frame, text="Search", style='Accent.TButton', command=self._run_query).pack(side='left', fill='x', expand=True)
        ttk.Button(button_frame, text="Clear", command=self._clear_query,
                   style='Accent.TButton').pack(side='left', fill='x', expand=True, padx=(12,0))

        control_card = tk.Frame(parent, bg=self.CARD, bd=0)
        control_card.pack(fill='x', padx=16, pady=(0,14))
        tk.Label(control_card, text="Threshold & details", bg=self.CARD, fg=self.TEXT,
                 font=(self.BOLD[0], 12)).pack(anchor='w', padx=14, pady=(14,8))

        slider_frame = tk.Frame(control_card, bg=self.CARD)
        slider_frame.pack(fill='x', padx=14, pady=(0,12))
        self.alpha_var = tk.DoubleVar(value=self.alpha)
        self.alpha_label = tk.Label(slider_frame, text=f"α = {self.alpha:.4f}",
                                    bg=self.CARD, fg=self.ACCENT2,
                                    font=(self.FONT[0], 10, 'bold'))
        self.alpha_label.pack(anchor='w', pady=(0,6))
        tk.Scale(slider_frame, from_=0.001, to=0.05,
                 resolution=0.001, orient='horizontal',
                 variable=self.alpha_var,
                 bg=self.CARD, fg=self.TEXT,
                 troughcolor=self.SURFACE, highlightthickness=0,
                 bd=0, command=self._update_alpha
                 ).pack(fill='x')

        info_card = tk.Frame(parent, bg=self.CARD, bd=0)
        info_card.pack(fill='both', expand=True, padx=16)
        tk.Label(info_card, text="How it works", bg=self.CARD, fg=self.TEXT,
                 font=(self.BOLD[0], 12)).pack(anchor='w', padx=14, pady=(14,8))
        rows = [
            ("Weighting",  "TF × IDF"),
            ("Similarity", "Cosine"),
            ("TF",         "raw term count"),
            ("IDF",        "log(N / df)"),
            ("Filter",     f"cosine ≥ α"),
            ("Stemmer",    "Porter"),
        ]
        for label, val in rows:
            r = tk.Frame(info_card, bg=self.CARD)
            r.pack(fill='x', padx=14, pady=4)
            tk.Label(r, text=label, bg=self.CARD, fg=self.MUTED,
                     font=(self.FONT[0], 9), width=12, anchor='w').pack(side='left')
            tk.Label(r, text=val,   bg=self.CARD, fg=self.ACCENT2,
                     font=(self.FONT[0], 9), anchor='w').pack(side='left')

        history_card = tk.Frame(parent, bg=self.CARD, bd=0)
        history_card.pack(fill='x', padx=16, pady=(14,0))
        tk.Label(history_card, text="Recent searches", bg=self.CARD, fg=self.TEXT,
                 font=(self.BOLD[0], 12)).pack(anchor='w', padx=14, pady=(14,8))
        self.hist_frame = tk.Frame(history_card, bg=self.CARD)
        self.hist_frame.pack(fill='x', padx=14, pady=(0,14))

    def _build_right(self, parent):
        top_cards = tk.Frame(parent, bg=self.BG)
        top_cards.pack(fill='x', pady=(0,14))

        for title, value, color in [
            ("Documents", str(self.N), self.ACCENT),
            ("Indexed terms", str(len(self.tfidf)), self.ACCENT2),
            ("Threshold", f"α={self.alpha:.3f}", self.MUTED),
        ]:
            card = tk.Frame(top_cards, bg=self.CARD, bd=0)
            card.pack(side='left', fill='x', expand=True, padx=6)
            tk.Label(card, text=title, bg=self.CARD, fg=self.MUTED,
                     font=(self.FONT[0], 9)).pack(anchor='w', padx=12, pady=(12,2))
            label = tk.Label(card, text=value, bg=self.CARD, fg=color,
                     font=(self.BOLD[0], 18))
            label.pack(anchor='w', padx=12, pady=(0,12))
            if title == "Threshold":
                self.threshold_value = label

        self.stats_bar = tk.Frame(parent, bg=self.SURFACE, bd=0)
        self.stats_bar.pack(fill='x', pady=(0,12), ipady=10)
        self.stats_bar.pack_propagate(False)

        self.stat_count = tk.Label(self.stats_bar, text="—",
                                   bg=self.SURFACE, fg=self.ACCENT,
                                   font=(self.BOLD[0], 24, "bold"))
        self.stat_count.pack(side='left', padx=(18,6), pady=12)

        stat_text = tk.Frame(self.stats_bar, bg=self.SURFACE)
        stat_text.pack(side='left', fill='x', expand=True, pady=12)
        tk.Label(stat_text, text="Documents found", bg=self.SURFACE, fg=self.MUTED,
                 font=(self.FONT[0], 9)).pack(anchor='w')
        self.stat_query = tk.Label(stat_text,
                                   text="Enter a query and press Search",
                                   bg=self.SURFACE, fg=self.TEXT,
                                   font=(self.FONT[0], 10))
        self.stat_query.pack(anchor='w', pady=(4,0))

        results_card = tk.Frame(parent, bg=self.CARD)
        results_card.pack(fill='both', expand=True)
        tk.Label(results_card, text="Search results", bg=self.CARD, fg=self.TEXT,
                 font=(self.BOLD[0], 12)).pack(anchor='w', padx=14, pady=(14,8))

        container = tk.Frame(results_card, bg=self.CARD)
        container.pack(fill='both', expand=True, padx=12, pady=(0,14))

        columns = ("rank", "doc_id", "filename", "score")
        self.results_tree = ttk.Treeview(container, columns=columns,
                                         show='headings', style='Result.Treeview', selectmode='browse')
        self.results_tree.heading('rank', text='Rank')
        self.results_tree.heading('doc_id', text='Doc ID')
        self.results_tree.heading('filename', text='Filename')
        self.results_tree.heading('score', text='Cosine')
        self.results_tree.column('rank', width=70, anchor='center')
        self.results_tree.column('doc_id', width=90, anchor='center')
        self.results_tree.column('filename', anchor='w', width=380)
        self.results_tree.column('score', width=120, anchor='center')
        self.results_tree.pack(side='left', fill='both', expand=True)

        scrollbar = ttk.Scrollbar(container, orient='vertical', command=self.results_tree.yview)
        scrollbar.pack(side='right', fill='y')
        self.results_tree.configure(yscrollcommand=scrollbar.set)

    def _set_placeholder(self):
        self.query_input.insert('1.0', 'e.g.  Search Trump speeches')
        self.query_input.config(fg=self.MUTED)
        self.query_input.bind('<FocusIn>',  self._clear_placeholder)
        self.query_input.bind('<FocusOut>', self._add_placeholder)

    def _clear_placeholder(self, e):
        if self.query_input.get('1.0', 'end-1c') == 'e.g.  Search Trump speeches':
            self.query_input.delete('1.0', 'end')
            self.query_input.config(fg=self.TEXT)

    def _clear_query(self):
        self.query_input.delete('1.0', 'end')
        self._add_placeholder(None)

    def _add_placeholder(self, e):
        if not self.query_input.get('1.0', 'end-1c').strip():
            self.query_input.insert('1.0', 'e.g.  Search Trump speeches')
            self.query_input.config(fg=self.MUTED)

    def _update_alpha(self, val):
        self.alpha = float(val)
        self.alpha_label.config(text=f"α = {self.alpha:.4f}")
        if hasattr(self, 'threshold_value'):
            self.threshold_value.config(text=f"α={self.alpha:.3f}")

    def _run_query(self):
        q = self.query_input.get('1.0', 'end-1c').strip()
        if not q or q == 'e.g.  Search Trump speeches': return

        try:
            results = vsm_query(q, self.tfidf, self.df, self.norms,
                                self.docmap, self.stopwords, alpha=self.alpha)
        except Exception as e:
            self.stat_count.config(text="ERR", fg=self.FAIL)
            self.stat_query.config(text=str(e))
            return

        color = self.PASS if results else self.FAIL
        self.stat_count.config(text=str(len(results)), fg=color)
        self.stat_query.config(text=f"Query: {q}  (α={self.alpha:.4f})", fg=self.MUTED)

        # Populate results table
        for item in self.results_tree.get_children():
            self.results_tree.delete(item)

        if not results:
            self.results_tree.insert('', 'end', values=("—", "—", "No documents found above threshold.", "—"))
        else:
            for rank, r in enumerate(results, 1):
                doc_id   = str(r['doc_id']).zfill(3)
                filename = r['filename']
                score    = f"{r['score']:.6f}"
                self.results_tree.insert(
                    '', 'end', values=(rank, doc_id, filename, score)
                )

        # Update history
        self._add_history(q, len(results))

    #History
    def _add_history(self, q, count):
        self.history = [h for h in self.history if h[0] != q]
        self.history.insert(0, (q, count))
        if len(self.history) > 6: self.history.pop()

        for w in self.hist_frame.winfo_children(): w.destroy()
        for hq, hc in self.history:
            row = tk.Frame(self.hist_frame, bg=self.CARD, cursor='hand2')
            row.pack(fill='x', pady=2)
            tk.Label(row, text="●", bg=self.CARD, fg=self.ACCENT,
                     font=(self.FONT[0], 8, 'bold')).pack(side='left', padx=(6,4), pady=4)
            tk.Label(row, text=hq, bg=self.CARD, fg=self.TEXT,
                     font=self.FONT, anchor='w').pack(side='left', fill='x', expand=True)
            tk.Label(row, text=f"{hc}", bg=self.CARD, fg=self.MUTED,
                     font=(self.FONT[0], 8)).pack(side='right', padx=8)
            for widget in [row] + row.winfo_children():
                widget.bind('<Button-1>', lambda e, q=hq: self._load_history(q))

    def _load_history(self, q):
        self.query_input.delete('1.0', 'end')
        self.query_input.config(fg=self.TEXT)
        self.query_input.insert('1.0', q)
        self._run_query()

if __name__ == '__main__':
    root = tk.Tk()
    app = VSMApp(root)
    root.mainloop()